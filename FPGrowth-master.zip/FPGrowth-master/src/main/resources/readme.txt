Three different sample files are attached here.
The first line of each file indicated the Threshold.
Next line is populated with baskets, which are tab delimited,
each basket has basket number followed by items in the basket, comma delimited.
