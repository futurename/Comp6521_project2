package FPtree;

import java.io.BufferedReader;  
import java.io.IOException;  
import java.io.InputStreamReader;  
import java.util.ArrayList;  
import java.util.BitSet;  
import java.util.Collections;  
import java.util.Comparator;  
import java.util.HashMap;  
import java.util.LinkedList;  
import java.util.List;  
import java.util.Map;  
import java.util.Map.Entry;  
import java.util.Set;  
   



import org.apache.hadoop.conf.Configuration;  
import org.apache.hadoop.conf.Configured;  
import org.apache.hadoop.fs.FSDataInputStream;  
import org.apache.hadoop.fs.FileSystem;  
import org.apache.hadoop.fs.Path;  
import org.apache.hadoop.io.IntWritable;  
import org.apache.hadoop.io.LongWritable;  
import org.apache.hadoop.io.Text;  
import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.mapreduce.Mapper;  
import org.apache.hadoop.mapreduce.Reducer;  
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;  
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;  
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;  
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;  
import org.apache.hadoop.util.Tool;  
import org.apache.hadoop.util.ToolRunner;  
   
public class FrequentSets_FPtree extends Configured implements Tool {  
   
    private static final int GroupSize = 30;  
    private static int threshold;  
   
    public static class GroupMapper extends Mapper<LongWritable, Text, IntWritable, Record> {  
        List<String> f1 = new LinkedList<String>(); // F1  
        List<List<String>> f1_group = new LinkedList<List<String>>(); // Grouped F1  
   
        @Override  
        public void setup(Context context) throws IOException {  
        		
        		for (String key : Prepare.itemCounter.keySet()) {
        			f1.add(key);
        		}
            // assign the group to f1 
            //Collections.shuffle(f1); 
            int cap = f1.size() / GroupSize; 
            
            System.out.println("cap:  " + cap);
            if (cap <= GroupSize) {f1_group.add(f1);}
            else {
            		for (int i = 0; i < GroupSize; i++) {  
            			List<String> list = new LinkedList<String>();  
            			for (int j = 0; j < cap; j++) {
            				list.add(f1.get(i * cap + j));  
            			}
            			System.out.println(list);
            			f1_group.add(list);  
            		}  
            		int remainder = f1.size() % GroupSize;  
            		int base = GroupSize * cap;  
            		for (int i = 0; i < remainder; i++) {  
            			f1_group.get(i).add(f1.get(base + i));  
            		}
            }
        }  
   
        @Override  
        public void map(LongWritable key, Text value, Context context)  
                throws IOException, InterruptedException {
        		int pos = value.toString().indexOf(",");
        		if (pos >= 0) {
        		String newvalue = value.toString().substring(pos + 1);
        		String[] arr = newvalue.toString().trim().split(",");  
        		Record record = new Record(arr);  
        		LinkedList<String> list = record.list;
        		BitSet bs=new BitSet(f1_group.size());  
        		bs.clear(); 
        		
        		//put the record to different key according the last item of the record and subrecord
        		while (record.list.size() > 0) {
        			String item = list.peekLast(); 
        			int i=0;  
        			for (; i < f1_group.size(); i++) {  
        				if(bs.get(i))  {continue;} 
        				if (f1_group.get(i).contains(item.trim())) {  
        					bs.set(i);  
        					break;  
        				}  
        			}  
        			if(i<f1_group.size()){     //find it
        				context.write(new IntWritable(i), record);    
        			}  
        			record.list.pollLast();  
        		}  
        	}
        }
    }  
       
    public static class FPReducer extends Reducer<IntWritable,Record,IntWritable,Text>{  
        public void reduce(IntWritable key,Iterable<Record> values,Context context)throws IOException,InterruptedException{  
            List<List<String>> trans=new LinkedList<List<String>>();  
            while(values.iterator().hasNext()){  
                Record record=values.iterator().next();  
                LinkedList<String> list=new LinkedList<String>();  
                for(String ele:record.list)  
                    list.add(ele);  
                trans.add(list);  
            }  
            FPGrowth(trans, null, context);  
        }  
        
        // FP-Growth算法  
    public void FPGrowth(List<List<String>> transRecords, List<String> postPattern,Context context) throws IOException, InterruptedException {  
        
    		// build the headerTable  
        ArrayList<TreeNode> HeaderTable = buildHeaderTable(transRecords);  
        // form the FP-Tree  
        TreeNode treeRoot = buildFPTree(transRecords, HeaderTable);  
        // if FP-Tree is null, just return 
        if (treeRoot.getChildren()==null || treeRoot.getChildren().size() == 0) {return;}  
        
        //output every header and each postPattern  
        if(postPattern!=null){  
            for (TreeNode header : HeaderTable) {  
                String outStr = header.getName();  
                int count=header.getCount();  
                for (String ele : postPattern)  
                    outStr += "	" + ele;  
                context.write(new IntWritable(count), new Text(outStr));  
            }  
        }  
        
        // find the conditional modle  
        for (TreeNode header : HeaderTable) {  
            // add one header to postPattern  
            List<String> newPostPattern = new LinkedList<String>();  
            newPostPattern.add(header.getName());  
            if (postPattern != null)  
                newPostPattern.addAll(postPattern);  
            // get the new TranRecords   
            List<List<String>> newTransRecords = new LinkedList<List<String>>();  
            TreeNode backnode = header.getNextHomonym();  
            while (backnode != null) {  
                int counter = backnode.getCount();  
                List<String> prenodes = new ArrayList<String>();  
                TreeNode parent = backnode;  
                // find all the backnode parents node，put it to the prenodes  
                while ((parent = parent.getParent()).getName() != null) {  
                    prenodes.add(parent.getName());  
                }  
                while (counter-- > 0) {  
                    newTransRecords.add(prenodes);  
                }  
                backnode = backnode.getNextHomonym();  
            }  
             
            FPGrowth(newTransRecords, newPostPattern,context);  
        }  
    }  
   
        // build the header   
        public ArrayList<TreeNode> buildHeaderTable(List<List<String>> transRecords) {  
            ArrayList<TreeNode> F1 = null;  
            if (transRecords.size() > 0) {  
                F1 = new ArrayList<TreeNode>();  
                Map<String, TreeNode> map = new HashMap<String, TreeNode>();  
                // count the support of the records  
                for (List<String> record : transRecords) {  
                    for (String item : record) {  
                        if (!map.keySet().contains(item)) {  
                            TreeNode node = new TreeNode(item);  
                            node.setCount(1);  
                            map.put(item, node);  
                        } else {  
                            map.get(item).countIncrement(1);  
                        }  
                    }  
                }  
                // get the F1  
                Set<String> names = map.keySet();  
                for (String name : names) {  
                    TreeNode tnode = map.get(name);  
                    if (tnode.getCount() >= threshold) {  
                        F1.add(tnode);  
                    }  
                }  
                Collections.sort(F1);  
                return F1;  
            } else {  
                return null;  
            }  
        }  
   
        // form the FP-Tree  
        public TreeNode buildFPTree(List<List<String>> transRecords,  
                ArrayList<TreeNode> F1) {  
            TreeNode root = new TreeNode();   
            for (List<String> transRecord : transRecords) {  
                LinkedList<String> record = sortByF1(transRecord, F1);  
                TreeNode subTreeRoot = root;  
                TreeNode tmpRoot = null;  
                if (root.getChildren() != null) {  
                    while (!record.isEmpty()  
                            && (tmpRoot = subTreeRoot.findChild(record.peek())) != null) {  
                        tmpRoot.countIncrement(1);  
                        subTreeRoot = tmpRoot;  
                        record.poll();  
                    }  
                }  
                addNodes(subTreeRoot, record, F1);  
            }  
            return root;  
        }  
   
        // sort the F1 
        public LinkedList<String> sortByF1(List<String> transRecord, ArrayList<TreeNode> F1) {  
            Map<String, Integer> map = new HashMap<String, Integer>();  
            for (String item : transRecord) {  
                
                for (int i = 0; i < F1.size(); i++) {  
                    TreeNode tnode = F1.get(i);  
                    if (tnode.getName().equals(item)) {  
                        map.put(item, i);  
                    }  
                }  
            }  
            ArrayList<Entry<String, Integer>> al = new ArrayList<Entry<String, Integer>>(  
                    map.entrySet());  
            Collections.sort(al, new Comparator<Map.Entry<String, Integer>>() {  
                @Override  
                public int compare(Entry<String, Integer> arg0,  
                        Entry<String, Integer> arg1) {  
                    // form big to small 
                    return arg0.getValue() - arg1.getValue();  
                }  
            });  
            LinkedList<String> rest = new LinkedList<String>();  
            for (Entry<String, Integer> entry : al) {  
                rest.add(entry.getKey());  
            }  
            return rest;  
        }  
   
        // put several node once time
        public void addNodes(TreeNode ancestor, LinkedList<String> record,  
                ArrayList<TreeNode> F1) {  
            if (record.size() > 0) {  
                while (record.size() > 0) {  
                    String item = record.poll();  
                    TreeNode leafnode = new TreeNode(item);  
                    leafnode.setCount(1);  
                    leafnode.setParent(ancestor);  
                    ancestor.addChild(leafnode);  
   
                    for (TreeNode f1 : F1) {  
                        if (f1.getName().equals(item)) {  
                            while (f1.getNextHomonym() != null) {  
                                f1 = f1.getNextHomonym();  
                            }  
                            f1.setNextHomonym(leafnode);  
                            break;  
                        }  
                    }  
                    addNodes(leafnode, record, F1);  
                }  
            }  
        }  
    }  
       
    public static class InverseMapper extends  Mapper<LongWritable, Text, Record, IntWritable> {  
        
    		@Override  
        public void map(LongWritable key, Text value, Context context)  throws IOException, InterruptedException {  
            
    			String []arr=value.toString().split("	");  
            int count=Integer.parseInt(arr[0]);  
            Record record=new Record();  
            for(int i=1;i<arr.length;i++){  
                record.list.add(arr[i]);  
            }  
            context.write(record, new IntWritable(count));  
        }  
    }  
       
    public static class MaxReducer extends Reducer<Record,IntWritable,IntWritable,Record>{  
        public void reduce(Record key,Iterable<IntWritable> values,Context context)throws IOException,InterruptedException{  
            int max=-1;  
            for(IntWritable value:values){  
                int i=value.get();  
                if(i>max)  
                    max=i;  
            }  
            context.write(new IntWritable(max), key);  
        }  
    }  
   
   
    @Override  
    public int run(String[] arg0) throws Exception {  
        Configuration conf=getConf();  
        conf.set("mapred.task.timeout", "6000000");  
        Job job=new Job(conf);  
        job.setJarByClass(FrequentSets_FPtree.class);  
        FileSystem fs=FileSystem.get(getConf());  
           
        FileInputFormat.setInputPaths(job, "/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/data/input.txt");  
        Path outDir=new Path("/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/output");   
        fs.delete(outDir,true);  
        FileOutputFormat.setOutputPath(job, outDir);  
           
        job.setMapperClass(GroupMapper.class);  
        job.setReducerClass(FPReducer.class);  
           
        job.setInputFormatClass(TextInputFormat.class);  
        job.setOutputFormatClass(TextOutputFormat.class);  
        job.setMapOutputKeyClass(IntWritable.class);  
        job.setMapOutputValueClass(Record.class);  
        job.setOutputKeyClass(IntWritable.class);  
        job.setOutputKeyClass(Text.class);  
           
        boolean success=job.waitForCompletion(true);  
           
        job=new Job(conf);  
        job.setJarByClass(FrequentSets_FPtree.class);  
           
        FileInputFormat.setInputPaths(job, "/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/output/part-r-*");  
        Path outDir2=new Path("/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/output2"); 
        fs.delete(outDir2,true);  
        FileOutputFormat.setOutputPath(job, outDir2);  
           
        job.setMapperClass(InverseMapper.class);  
        job.setReducerClass(MaxReducer.class);  
        //job.setNumReduceTasks(0);  
           
        job.setInputFormatClass(TextInputFormat.class);  
        job.setOutputFormatClass(TextOutputFormat.class);  
        job.setMapOutputKeyClass(Record.class);  
        job.setMapOutputValueClass(IntWritable.class);  
        job.setOutputKeyClass(IntWritable.class);  
        job.setOutputKeyClass(Record.class);  
           
        success |= job.waitForCompletion(true);  
           
        return success?0:1;  
    }  
   
    public static void main(String[] args) throws Exception{ 
    		
    	 	long startTime1 = System.currentTimeMillis();   //get the start time  
    	
    		Prepare p = new Prepare();
    		threshold = p.preparing();
		
        int res=ToolRunner.run(new Configuration(), new FrequentSets_FPtree(), args);
        
        String content = "";
        for (String key : Prepare.itemCounter.keySet()) {
        		content += Prepare.itemCounter.get(key) + "  " + key +  "\r";
        }
        
        Output.addTXT("part-r-00000", content);
       
        long endTime1=System.currentTimeMillis(); //get the end time
        System.out.println("The processing time is: " + (endTime1-startTime1) + "ms"); 
        
        System.exit(res); 
   
    }  
}  
