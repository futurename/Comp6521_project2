package FPtree;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;


public class Output {
	
	public static void printTXT(String fileName, String note) throws Exception{
		
		File file=new File("/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/input");
			if  (!file .isDirectory()) {         
			    //file not exist, create the file    
			    file .mkdir();
			}
		File filelog=new File("/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/input/" + fileName); 
			if (!filelog.exists()){  
				filelog.createNewFile();
				FileWriter out = new FileWriter(filelog);
				PrintWriter pw = new PrintWriter(out);
				pw.print(note);
				pw.println("  ");
				pw.close();
			}
			else{
				FileWriter out = new FileWriter(filelog, true);   
				PrintWriter pw = new PrintWriter(out);
				pw.print(note);	
				pw.close();
			}   
		}
	
public static void addTXT(String fileName, String note) throws Exception{
	
		File filelog=new File("/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/output2/" + fileName); 
			if (!filelog.exists()){  
				filelog.createNewFile();
				FileWriter out = new FileWriter(filelog);
				PrintWriter pw = new PrintWriter(out);
				pw.print(note);
				pw.println("  ");
				pw.close();
			}
			else{
				FileWriter out = new FileWriter(filelog, true);   
				PrintWriter pw = new PrintWriter(out);
				pw.print(note);	
				pw.close();
			}   
		}
}
