package FPtree;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;


public class Prepare {
	private int threshold;
	public static HashMap<String, Integer> itemCounter;
	
	public Prepare() {
		threshold = 0;
		itemCounter = new HashMap<String, Integer>();
	}
	
	
	public int preparing() throws Exception {
		CreateBasketListFromFileAndCountSingleItems();
		DeleteInfrequentItems();
		return threshold;
	}
		
	/* read the file
	 * create the ArrayList basketList
	 * and count each single items
	 */
    public void CreateBasketListFromFileAndCountSingleItems() throws IOException {

        try{
        		File file = new File("/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/data/input.txt");
        		InputStreamReader reader = new InputStreamReader(new FileInputStream(file));  
			BufferedReader br = new BufferedReader(reader);  
			String tempLine = br.readLine();
			threshold = Integer.valueOf(tempLine);
			//System.out.println("thershold : " + threshold);
			
			tempLine = br.readLine(); 
			while (tempLine != null) {
				
				String[] bskLst = tempLine.split("	");
				
				for (String bsk : bskLst) {
					String[] elements = bsk.split(",");
					//int bskID = Integer.valueOf(elements[0]);
					for (int i = 1; i < elements.length; i++) {
						if(itemCounter.containsKey(elements[i])) {
							int count = itemCounter.get(elements[i]) +1;
							itemCounter.put(elements[i], count);
						}
						else {
							itemCounter.put(elements[i], 1);	
						}
					}
				}
				tempLine = br.readLine();
	        }
		br.close();
        }catch (Exception ex){
        		System.out.println("Exception : " + ex);
        }
        				
    }
    
    // delete the infrequent item
    public void DeleteInfrequentItems() {
    		Iterator<HashMap.Entry<String, Integer>> iter = itemCounter.entrySet().iterator();
    		while(iter.hasNext()){
    			HashMap.Entry<String, Integer> each = iter.next();
    			if( each.getValue() < threshold ) {
    				iter.remove();
    			}
    		}
    		
    }
    
}

   