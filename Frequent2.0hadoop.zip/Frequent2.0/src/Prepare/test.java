package Prepare;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;

import FPtree.Basket;

public class test {
	
	 
	public static void main(String[] args) throws IOException, InterruptedException {
		
		List<List<String>> transRecords = new LinkedList<List<String>>();
	
    			File file = new File("/Users/Ling/Desktop/eclipse-workspace/Frequent2.0/data/input_3.txt");
    			InputStreamReader reader = new InputStreamReader(new FileInputStream(file)); // 建立一个输入流对象reader  
    			BufferedReader br = new BufferedReader(reader); // 建立一个对象，它把文件内容转成计算机能读懂的语言   
    			String tempLine = br.readLine();
    			int threshold = Integer.valueOf(tempLine);
    			//System.out.println("thershold : " + threshold);
		
    			tempLine = br.readLine(); // 一次读入一行数据
    			while (tempLine != null) {
    				String line = tempLine.substring(tempLine.indexOf(",") + 1);
    				//System.out.println("tempLine : " + tempLine);
    				List<String> record = new LinkedList<String>(); 
    				String[] items = tempLine.trim().split(",");
    				for (String i : items) {	
    					record.add(i);
				}
    				transRecords.add(record);
    				tempLine = br.readLine();
        }
		
		FPgrowth fp = new FPgrowth(threshold);
		fp.FPGrowth(transRecords, null);
	}
}
